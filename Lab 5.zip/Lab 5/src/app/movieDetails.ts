import {Movies} from './movies';
export const movies:Movies[]=[
    {name:'Super 30',rating:3.5,genre:'Drama'},
    {name:'The Lion King',rating:4.0,genre:'Animated'},
    {name:'Stree',rating:3.5,genre:'Horror Comedy'},
    {name:'Arjun Patiala',rating:3.5,genre:'Comedy'}
];