import { Component, OnInit } from '@angular/core';
import data1 from '../data1/search.json';
@Component({
  selector: 'app-searching',
  templateUrl: './searching.component.html',
  styleUrls: ['./searching.component.css']
})
export class SearchingComponent implements OnInit {
employees=data1;
  constructor() { }

  ngOnInit() {
  }
search(event)
{
  this.employees=this.employees.filter(singleItem =>singleItem.bookid.toLowerCase().includes(event.target.value.toLowerCase()))
}
search1(event)
{
  this.employees=this.employees.filter(singleItem =>singleItem.booktitle.toLowerCase().includes(event.target.value.toLowerCase()))
}
search2(event)
{
  this.employees=this.employees.filter(singleItem =>singleItem.bookauthor.toLowerCase().includes(event.target.value.toLowerCase()))
}
search3(event)
{
  this.employees=this.employees.filter(singleItem =>singleItem.bookyear.toLowerCase().includes(event.target.value.toLowerCase()))
}
}