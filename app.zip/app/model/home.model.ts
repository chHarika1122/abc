export class home
{
    id:any;
    name:any;
    salary:any;
    department:any;
}