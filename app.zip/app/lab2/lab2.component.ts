import { Component, OnInit } from '@angular/core';
import { home } from '../model/home.model';
@Component({
  selector: 'app-lab2',
  templateUrl: './lab2.component.html',
  styleUrls: ['./lab2.component.css']
})
export class Lab2Component implements OnInit {
  home = new home;
  employees = [];
  flag = 0;
 caption:string=' ';
  index: any;
  flag1: boolean;

  constructor() { }

  ngOnInit() {
    // this.http.get('https://jsonplaceholder.typicode.com/posts').subscribe(Response => Response = this.employees)
  }
  addEmployee() {
    this.employees.push(this.home);
    this.home = new home;
    this.flag++;
    this.caption='Data Inserted';
  }
  delete(i) {
    this.employees.splice(i, 1);
    this.caption='Data Deleted';
  }
  update(i)
  {
    this.index=i;
    this.flag1=true
  }
  updata(form)
  {
    if(form.id!=null)
      this.employees[this.index].id=form.id
      if(form.name!=null)
      this.employees[this.index].name=form.name
      if(form.salary!=null)
      this.employees[this.index].salary=form.salary
      if(form.department!=null)
      this.employees[this.index].department=form.department
      this.flag1=false
      this.caption="Data Updated";
  }
}
